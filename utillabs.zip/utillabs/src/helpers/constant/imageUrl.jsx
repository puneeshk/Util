import Logo from '../../icon/logo.svg'
import ALS from '../../icon/ALS.png'
import Banner from '../../icon/Banner.png'
import Banner2 from '../../icon/Banner2.png'
import Banner3 from '../../icon/Banner3.png'
import Banner4 from '../../icon/Banner4.png'
import Banner5 from '../../icon/Banner5.png'
import kumarOrganic from '../../icon/kumarOrganic.png'
import SalesforcePartner from '../../icon/salesforcePartner.svg'
import AuthorizedCloudReseller from '../../icon/authorizedCloudReseller.svg'
import VideoThumb from '../../icon/videoThumb.jpg'
import Video from '../../icon/video.mp4'
import DotPattern from '../../icon/dotPattern.svg'
import DotPatternBlue from '../../icon/dotPatternBlue.svg'
import Azzite from '../../icon/azzite.png'
import Beepkart from '../../icon/beepkart.png'
import Bisleri from '../../icon/Bisleri.png'
import Cme from '../../icon/cme.png'
import Ecolibrium from '../../icon/ecolibrium.png'
import Excelr from '../../icon/excelr.png'
import F2 from '../../icon/F2.png'
import Finexus from '../../icon/finexus.png'
import FinanceBuddha from '../../icon/FinanceBuddha.png'
import FlameUniversity from '../../icon/FlameUniversity.png'
import Flobiz from '../../icon/flobiz.png'
import Homeskul from '../../icon/homeskul.png'
import Kult from '../../icon/Kult.png'
import mCaffeine from '../../icon/mCaffeine.png'
import oasis from '../../icon/oasis.png'
import Quizziz from '../../icon/Quizziz.png'
import relevel from '../../icon/relevel.png'
import Soliflex from '../../icon/Soliflex.png'
import Swagelok from '../../icon/swagelok.png'
import SwarnaMahal from '../../icon/swarnaMahal.png'
import Symega from '../../icon/symega.png'
import Trevi from '../../icon/trevi.png'
import Tridasa from '../../icon/tridasa.png'
import UWA from '../../icon/UWA.png'
import WeWork from '../../icon/WeWork.png'
import CloudPoweredEfficiency from '../../icon/CloudPoweredEfficiency.jpg'
import SmartAnalytics from '../../icon/SmartAnalytics.jpg'
import SuperiorSupport from '../../icon/SuperiorSupport.jpg'
import Highlight from '../../icon/highlight.svg'
import CheckCircle from '../../icon/CheckCircle.svg'
import Salesforce from '../../icon/salesforce.svg'
import Graph from '../../icon/Graph.svg'
import Heart from '../../icon/Heart.svg'
import Search from '../../icon/Search.svg'
import Cart from '../../icon/Cart.svg'
import Location from '../../icon/Location.svg'
import Heroku from '../../icon/Heroku.svg'
import CPQ from '../../icon/CPQ.svg'
import RightArrow from '../../icon/RightArrow.svg'
import ArrowNarrowRight from '../../icon/ArrowNarrowRight.svg'
import Banking from '../../icon/Banking.svg'
import Healthcare from '../../icon/Healthcare.svg'
import Education from '../../icon/Education.svg'
import Manufacturing from '../../icon/Manufacturing.svg'
import Fintech from '../../icon/Fintech.svg'
import Recruitment from '../../icon/Recruitment.svg'
import Tourism from '../../icon/Tourism.svg'
import Avatar from '../../icon/avatar.png'
import LinePattern from '../../icon/linePattern.svg'
import Wave from '../../icon/wave.svg'
import Quotes from '../../icon/Quotes.svg'
import Neemans from '../../icon/Neemans.png'
import Croyez from '../../icon/Croyez.png'
import Renaatus from '../../icon/Renaatus.png'
import Vaishnavi from '../../icon/Vaishnavi.png'
import Thrillophilia from '../../icon/Thrillophilia.png'
import Edwardian from '../../icon/Edwardian.png'
import goeasy from '../../icon/goeasy.png'
import Graciepoint from '../../icon/Graciepoint.png'
import Creditworks from '../../icon/Creditworks.png'
import Ascendus from '../../icon/Ascendus.png'
import NorthernArc from '../../icon/NorthernArc.png'
import NationalFunding from '../../icon/NationalFunding.png'
import Hirect from '../../icon/Hirect.png'
import Ondonte from '../../icon/Ondonte.png'
import Leaders from '../../icon/Leaders.png'
import AqmenMedtech from '../../icon/AqmenMedtech.png'
import Ekincare from '../../icon/Ekincare.png'
import Twin from '../../icon/Twin.png'
import ArjunNatural from '../../icon/ArjunNatural.png'
import Cyberpeace from '../../icon/Cyberpeace.png'
import FoundationExcellence from '../../icon/FoundationExcellence.png'
import BottlesForChange from '../../icon/BottlesForChange.png'
import AmnestyInternational from '../../icon/AmnestyInternational.png'
import IGSTC from '../../icon/IGSTC.png'
import ArrowBendUpRight from '../../icon/ArrowBendUpRight.svg'
import Pattern from '../../icon/Pattern.png'


export {
    ArrowBendUpRight,
    Avatar,
    Azzite,
    ALS,
    AuthorizedCloudReseller,
    Banner,
    Banner2,
    Banner3,
    Banner4,
    Banner5,
    Beepkart,
    Bisleri,
    Cme,
    CheckCircle,
    CloudPoweredEfficiency,
    Ecolibrium,
    Excelr,
    F2,
    Finexus,
    FlameUniversity,
    Flobiz,
    Homeskul,
    Highlight,
    Kult,
    LinePattern,
    mCaffeine,
    oasis,
    Quizziz,
    FinanceBuddha,
    relevel,
    Soliflex,
    Swagelok,
    SwarnaMahal,
    Symega,
    SmartAnalytics,
    SuperiorSupport,
    Trevi,
    Tridasa,
    UWA,
    WeWork,
    Logo,
    SalesforcePartner,
    Salesforce,
    VideoThumb,
    Video,
    kumarOrganic,
    DotPattern,
    DotPatternBlue,
    Graph,
    Heart,
    Search,
    Cart,
    Location,
    Heroku,
    CPQ,
    RightArrow,
    ArrowNarrowRight,
    Banking,
    Healthcare,
    Education,
    Manufacturing,
    Fintech,
    Pattern,
    Recruitment,
    Tourism,
    Wave,
    Quotes,
    Neemans,
    Croyez,
    Renaatus,
    Vaishnavi,
    Thrillophilia,
    Edwardian,
    goeasy,
    Graciepoint,
    Creditworks,
    Ascendus,
    NorthernArc,
    NationalFunding,
    Hirect,
    Ondonte,
    Leaders,
    AqmenMedtech,
    Ekincare,
    Twin,
    ArjunNatural,
    Cyberpeace,
    FoundationExcellence,
    BottlesForChange,
    AmnestyInternational,
    IGSTC
}