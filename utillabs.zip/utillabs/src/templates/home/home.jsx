import { Container } from '@mui/material'
import React from "react";
import Slider from "react-slick";
import Grid from '@mui/material/Grid2'
import { Tab, Tabs } from '@mui/material';
import AtomTextField from '../../atoms/textField/textField'
import AtomTabs from '../../atoms/tabs/tabs'
import AtomTabPanel from '../../atoms/tabs/tabPanel'
import AtomButton from '../../atoms/button/button'
import PromotionalBanner from '../promotionalBanner/promotionalBanner'
import { SOLUTION_TABS, PROVIDE_SOLUTION_TABS } from './constant'
import {
    ALS, 
    ArrowBendUpRight,
    Avatar, 
    Banner,
    Banner2,
    Banner3,
    Banner4,
    Banner5,
    Video, 
    VideoThumb, 
    kumarOrganic,
    Cme, 
    Symega, 
    Swagelok, 
    Quotes, 
    DotPatternBlue, 
    LinePattern, 
    Soliflex, 
    F2, 
    Trevi, 
    Ecolibrium, 
    Flobiz, 
    Azzite, 
    Finexus, 
    Quizziz, 
    Excelr, 
    FinanceBuddha,
    Homeskul, 
    relevel, 
    FlameUniversity, 
    UWA, 
    Bisleri, 
    Kult, 
    mCaffeine, 
    SwarnaMahal, 
    Beepkart, 
    oasis, 
    Tridasa, 
    WeWork, 
    CloudPoweredEfficiency, 
    SmartAnalytics, 
    SuperiorSupport, 
    Highlight, 
    CheckCircle, 
    Salesforce, 
    Graph, 
    RightArrow, 
    Heart, 
    Search,
    Pattern, 
    Cart, 
    Location, 
    Heroku, 
    CPQ, 
    ArrowNarrowRight, 
    Banking, 
    Healthcare, 
    Education, 
    Manufacturing, 
    Fintech, 
    Recruitment, 
    Tourism, 
    Wave,
    Neemans,
    Croyez,
    Renaatus,
    Vaishnavi,
    Thrillophilia,
    Edwardian,
    goeasy,
    Graciepoint,
    Creditworks,
    Ascendus,
    NorthernArc,
    NationalFunding,
    Hirect,
    Ondonte,
    Leaders,
    AqmenMedtech,
    Ekincare,
    Twin,
    ArjunNatural,
    Cyberpeace,
    FoundationExcellence,
    BottlesForChange,
    AmnestyInternational,
    IGSTC
} from '../../helpers/constant/imageUrl'
import './home.scss'
import { useEffect, useState } from 'react'
import { useSpring, animated } from 'react-spring'

const HomeTemplate = () => {
    const svgs = {
        svg1: {
            path1: 'M1310 10L1241.29 84.5115C1234.48 91.8986 1230.7 101.579 1230.7 111.627V317.283C1230.7 330.275 1224.39 342.457 1213.78 349.953L614.155 773.547C603.544 781.043 597.234 793.225 597.234 806.217V917.121C597.234 929.924 591.105 941.954 580.748 949.48L426.569 1061.52C416.212 1069.05 410.083 1081.08 410.083 1093.88V1565.12C410.083 1580.36 401.433 1594.26 387.772 1601L255.94 1666C242.279 1672.74 233.629 1686.64 233.629 1701.88V1789V1801.68C233.629 1817.65 224.128 1832.09 209.461 1838.42L-10 1933',
            path2: 'M395 6L367.93 35.0898C363.798 39.531 361.5 45.3726 361.5 51.4393V131.335C361.5 139.26 357.587 146.675 351.044 151.148L243.956 224.352C237.413 228.825 233.5 236.24 233.5 244.165V308.171C233.5 315.91 229.769 323.173 223.478 327.681L16.0219 476.319C9.73137 480.827 6 488.09 6 495.829V685V788.5V813.467C6 819.886 8.57182 826.038 13.1407 830.548L75.9901 892.581C80.4816 897.014 86.5385 899.5 92.8494 899.5H158.022C165.28 899.5 172.149 902.785 176.705 908.435L359 1134.5L365.87 1142.16C369.817 1146.57 372 1152.27 372 1158.18V1522.33C372 1526.06 372.867 1529.73 374.534 1533.07L397 1578',
            viewbox1: '0 0 1300 1943',
            viewbox2: '0 0 394 1584',
        }
    }
    const els = document.querySelectorAll(".animate__section");
    const paths = document.querySelectorAll(".svg__path");
    paths.forEach((path, _i) => {
        const { path1, path2, viewbox1, viewbox2 } = svgs[`svg${_i+1}`];
        console.log({path1}, {path2});
        if (window.innerWidth < 768) {
            path.setAttribute('d', path2);
            path.parentElement.setAttribute('viewBox', viewbox2)
        } else {
            path.setAttribute('d', path1);
            path.parentElement.setAttribute('viewBox', viewbox1)
        }
        const length = path.getTotalLength();
        path.style.strokeDasharray = length;
        path.style.strokeDashoffset = length;
    })
    function getPercentage(currentNum, minAllowed, maxAllowed, min, max) {
        return (maxAllowed - minAllowed) * (currentNum- min) / (max - min) + minAllowed;
      }
      
      window.addEventListener("scroll", myFunction);
      
      const startPoint = 0;
      const endPoint = 0;
      function myFunction() {
        const winY = window.scrollY;
        const winHeight = window.innerHeight / 2;
        els.forEach((el, __index) => {
          const elOffsetTop = el.offsetTop;
          const currentPath = paths[__index];
          const lastIndex = __index === (els.length - 1);
          const length = currentPath.getTotalLength();
          startPoint = elOffsetTop - (lastIndex ? 0 : winHeight);
          endPoint = elOffsetTop + el.clientHeight;
          if (winY >= startPoint) {
            const percentage = getPercentage(winY, 0, 100, startPoint, endPoint);
            if (winY >= endPoint) {
              currentPath.style.strokeDashoffset = 0;
              return;
            }
            currentPath.style.strokeDashoffset = length - (length * percentage / 100);
          } else {
            currentPath.style.strokeDashoffset = length;
          }
        });
    }

    var settings = {
        dots: false,
        infinite: false,
        speed: 500,
        slidesToShow: 1,
        slidesToScroll: 1
      };
    const [currentTab, setCurrentTab] = useState(0)
    const handleTabChange = (event, newValue) => {
        setCurrentTab(newValue)
    }
    function Number({ n }) {
        const { number } = useSpring({
            from: { number: 0 },
            number: n,
            delay: 200,
            config: { mass: 1, tension: 20, friction: 10 }
        });
        return <animated.div>{number.to((n) => n.toFixed(0))}</animated.div>
    }
    return (
        <>
            <PromotionalBanner 
                heading={'We Supercharge Businesses using Salesforce to Serve their'} 
                span={'Customers'} 
                secndaryButton={true}
                secndaryButtonText="contact us"
                primaryButton={true}
                primaryButtonText="Schedule a call"
                video={true}
                videoPoster={VideoThumb}
                videoSrc={Video}
            />
            <div className='trusted-companies'>
                <h2>Trusted by 50+ Companies</h2>
                <div className="brand-slider">
                    <div className="slide-track">
                        <div className="slide">
                            <img src={Cme} alt="" />
                        </div>
                        <div className="slide">
                            <img src={Symega} alt="" />
                        </div>
                        <div className="slide">
                            <img src={Swagelok} alt="" />
                        </div>
                        <div className="slide">
                            <img src={Soliflex} alt="" />
                        </div>
                        <div className="slide">
                            <img src={F2} alt="" />
                        </div>
                        <div className="slide">
                            <img src={Trevi} alt="" />
                        </div>
                        <div className="slide">
                            <img src={Ecolibrium} alt="" />
                        </div>
                        <div className="slide">
                            <img src={Flobiz} alt="" />
                        </div>
                        <div className="slide">
                            <img src={Azzite} alt="" />
                        </div>
                        <div className="slide">
                            <img src={Finexus} alt="" />
                        </div>
                        <div className="slide">
                            <img src={Quizziz} alt="" />
                        </div>
                        <div className="slide">
                            <img src={Excelr} alt="" />
                        </div>
                        <div className="slide">
                            <img src={Homeskul} alt="" />
                        </div>
                        <div className="slide">
                            <img src={relevel} alt="" />
                        </div>
                        <div className="slide">
                            <img src={FlameUniversity} alt="" />
                        </div>
                        <div className="slide">
                            <img src={UWA} alt="" />
                        </div>
                        <div className="slide">
                            <img src={Bisleri} alt="" />
                        </div>
                        <div className="slide">
                            <img src={Kult} alt="" />
                        </div>
                        <div className="slide">
                            <img src={mCaffeine} alt="" />
                        </div>
                        <div className="slide">
                            <img src={SwarnaMahal} alt="" />
                        </div>
                        <div className="slide">
                            <img src={Beepkart} alt="" />
                        </div>
                        <div className="slide">
                            <img src={oasis} alt="" />
                        </div>
                        <div className="slide">
                            <img src={Tridasa} alt="" />
                        </div>
                        <div className="slide">
                            <img src={WeWork} alt="" />
                        </div>
                    </div>
                    <div className="slide-track">
                        <div className="slide">
                            <img src={Cme} alt="" />
                        </div>
                        <div className="slide">
                            <img src={Symega} alt="" />
                        </div>
                        <div className="slide">
                            <img src={Swagelok} alt="" />
                        </div>
                        <div className="slide">
                            <img src={Soliflex} alt="" />
                        </div>
                        <div className="slide">
                            <img src={F2} alt="" />
                        </div>
                        <div className="slide">
                            <img src={Trevi} alt="" />
                        </div>
                        <div className="slide">
                            <img src={Ecolibrium} alt="" />
                        </div>
                        <div className="slide">
                            <img src={Flobiz} alt="" />
                        </div>
                        <div className="slide">
                            <img src={Azzite} alt="" />
                        </div>
                        <div className="slide">
                            <img src={Finexus} alt="" />
                        </div>
                        <div className="slide">
                            <img src={Quizziz} alt="" />
                        </div>
                        <div className="slide">
                            <img src={Excelr} alt="" />
                        </div>
                        <div className="slide">
                            <img src={Homeskul} alt="" />
                        </div>
                        <div className="slide">
                            <img src={relevel} alt="" />
                        </div>
                        <div className="slide">
                            <img src={FlameUniversity} alt="" />
                        </div>
                        <div className="slide">
                            <img src={UWA} alt="" />
                        </div>
                        <div className="slide">
                            <img src={Bisleri} alt="" />
                        </div>
                        <div className="slide">
                            <img src={Kult} alt="" />
                        </div>
                        <div className="slide">
                            <img src={mCaffeine} alt="" />
                        </div>
                        <div className="slide">
                            <img src={SwarnaMahal} alt="" />
                        </div>
                        <div className="slide">
                            <img src={Beepkart} alt="" />
                        </div>
                        <div className="slide">
                            <img src={oasis} alt="" />
                        </div>
                        <div className="slide">
                            <img src={Tridasa} alt="" />
                        </div>
                        <div className="slide">
                            <img src={WeWork} alt="" />
                        </div>
                    </div>
                </div>
                <div className="brand-slider">
                    <div className="slide-track reserve">
                        <div className="slide">
                            <img src={Neemans} alt="" />
                        </div>
                        <div className="slide">
                            <img src={Croyez} alt="" />
                        </div>
                        <div className="slide">
                            <img src={Renaatus} alt="" />
                        </div>
                        <div className="slide">
                            <img src={Vaishnavi} alt="" />
                        </div>
                        <div className="slide">
                            <img src={Thrillophilia} alt="" />
                        </div>
                        <div className="slide">
                            <img src={Edwardian} alt="" />
                        </div>
                        <div className="slide">
                            <img src={goeasy} alt="" />
                        </div>
                        <div className="slide">
                            <img src={Graciepoint} alt="" />
                        </div>
                        <div className="slide">
                            <img src={Creditworks} alt="" />
                        </div>
                        <div className="slide">
                            <img src={Ascendus} alt="" />
                        </div>
                        <div className="slide">
                            <img src={NorthernArc} alt="" />
                        </div>
                        <div className="slide">
                            <img src={NationalFunding} alt="" />
                        </div>
                        <div className="slide">
                            <img src={Hirect} alt="" />
                        </div>
                        <div className="slide">
                            <img src={Ondonte} alt="" />
                        </div>
                        <div className="slide">
                            <img src={Leaders} alt="" />
                        </div>
                        <div className="slide">
                            <img src={AqmenMedtech} alt="" />
                        </div>
                        <div className="slide">
                            <img src={Ekincare} alt="" />
                        </div>
                        <div className="slide">
                            <img src={Twin} alt="" />
                        </div>
                        <div className="slide">
                            <img src={ArjunNatural} alt="" />
                        </div>
                        <div className="slide">
                            <img src={Cyberpeace} alt="" />
                        </div>
                        <div className="slide">
                            <img src={FoundationExcellence} alt="" />
                        </div>
                        <div className="slide">
                            <img src={BottlesForChange} alt="" />
                        </div>
                        <div className="slide">
                            <img src={AmnestyInternational} alt="" />
                        </div>
                        <div className="slide">
                            <img src={IGSTC} alt="" />
                        </div>
                    </div>
                    <div className="slide-track reserve">
                        <div className="slide">
                            <img src={Neemans} alt="" />
                        </div>
                        <div className="slide">
                            <img src={Croyez} alt="" />
                        </div>
                        <div className="slide">
                            <img src={Renaatus} alt="" />
                        </div>
                        <div className="slide">
                            <img src={Vaishnavi} alt="" />
                        </div>
                        <div className="slide">
                            <img src={Thrillophilia} alt="" />
                        </div>
                        <div className="slide">
                            <img src={Edwardian} alt="" />
                        </div>
                        <div className="slide">
                            <img src={goeasy} alt="" />
                        </div>
                        <div className="slide">
                            <img src={Graciepoint} alt="" />
                        </div>
                        <div className="slide">
                            <img src={Creditworks} alt="" />
                        </div>
                        <div className="slide">
                            <img src={Ascendus} alt="" />
                        </div>
                        <div className="slide">
                            <img src={NorthernArc} alt="" />
                        </div>
                        <div className="slide">
                            <img src={NationalFunding} alt="" />
                        </div>
                        <div className="slide">
                            <img src={Hirect} alt="" />
                        </div>
                        <div className="slide">
                            <img src={Ondonte} alt="" />
                        </div>
                        <div className="slide">
                            <img src={Leaders} alt="" />
                        </div>
                        <div className="slide">
                            <img src={AqmenMedtech} alt="" />
                        </div>
                        <div className="slide">
                            <img src={Ekincare} alt="" />
                        </div>
                        <div className="slide">
                            <img src={Twin} alt="" />
                        </div>
                        <div className="slide">
                            <img src={ArjunNatural} alt="" />
                        </div>
                        <div className="slide">
                            <img src={Cyberpeace} alt="" />
                        </div>
                        <div className="slide">
                            <img src={FoundationExcellence} alt="" />
                        </div>
                        <div className="slide">
                            <img src={BottlesForChange} alt="" />
                        </div>
                        <div className="slide">
                            <img src={AmnestyInternational} alt="" />
                        </div>
                        <div className="slide">
                            <img src={IGSTC} alt="" />
                        </div>
                    </div>
                </div>
            </div>
            <div className='why-salesforce'>
                <Container className='container'>
                    <h3>Why Salesforce?</h3>
                    <Grid container justifyContent="space-between">
                        <Grid size={{ xs: 12, md: 3.25 }}>
                            <img src={CloudPoweredEfficiency} alt='' className='circle-thumb' />  
                            <h4>Cloud-Powered Efficiency and Customer Insights</h4> 
                            <p>Get a complete view of customers for personalized Engagement and Informed Decision-Making anytime and anywhere.</p>                      
                        </Grid>
                        <Grid size={{ xs: 12, md: 3.25 }}>
                            <img src={SmartAnalytics} alt='' className='circle-thumb' />  
                            <h4>Flexibility, Integration and Smart Analytics</h4> 
                            <p>Leverage data for predictive insights and refine strategies with Einstein Analytics. Expand functionality with third-party apps.</p>                      
                        </Grid>
                        <Grid size={{ xs: 12, md: 3.25 }}>
                            <img src={SuperiorSupport} alt='' className='circle-thumb' />  
                            <h4>Superior Support and Scalability Assured</h4> 
                            <p>Deliver exceptional customer service with Service Cloud. Salesforce adapts as your business grows.</p>                      
                        </Grid>
                    </Grid>
                </Container>
            </div>
            <div className='salesforce-anyone animate__section'>
                <Container className='container'>
                    <Grid container justifyContent="space-between">
                        <Grid size={{ xs: 12, md: 6 }}>
                            <h4>
                                Salesforce is for <span>Anyone</span>
                                <img src={Highlight} alt='' className='highlight' />  
                            </h4>
                            <ul>
                                <li>
                                    <img src={CheckCircle} alt='' />  
                                    User-Friendly Interface
                                </li>
                                <li>
                                    <img src={CheckCircle} alt='' />
                                    Quick Adoption
                                </li>
                                <li>
                                    <img src={CheckCircle} alt='' />
                                    Customized Experiences
                                </li>
                                <li>
                                    <img src={CheckCircle} alt='' />
                                    Mobile Accessibility
                                </li>
                                <li>
                                    <img src={CheckCircle} alt='' />
                                    Minimal Learning Curve
                                </li>
                            </ul>
                        </Grid>
                        <Grid size={{ xs: 12, md: 6 }} display="flex" justifyContent="right">
                            <div className='circle1'>
                                <div className='icon-set'>
                                    <div className="icon">
                                        <img src={Heart} alt='' />
                                    </div>
                                    <div className="icon">
                                        <img src={Graph} alt='' />
                                    </div>
                                    <div className="icon">
                                        <img src={Search} alt='' />
                                    </div>
                                    <div className="icon">
                                        <img src={Cart} alt='' />
                                    </div>
                                    <div className="icon">
                                        <img src={Location} alt='' />
                                    </div>
                                    <div className="icon">
                                        <img src={Heroku} alt='' />
                                    </div>
                                    <div className="icon">
                                        <img src={CPQ} alt='' />
                                    </div>
                                </div>
                                <img src={Salesforce} alt='' />
                                <div className='circle2'></div>
                                <div className='circle3'></div>
                                <div className='circle4'></div>
                                <div className='circle5'></div>
                                <div className='circle6'></div>
                                <div className='circle7'></div>
                            </div>
                        </Grid>
                    </Grid>
                </Container>
                <div id="line-drawing">
                    <svg xmlns="http://www.w3.org/2000/svg" width="100%" viewBox="0 0 1300 1943" fill="none">
                        <path class="svg__path" id="myLine" d="M1310 10L1241.29 84.5115C1234.48 91.8986 1230.7 101.579 1230.7 111.627V317.283C1230.7 330.275 1224.39 342.457 1213.78 349.953L614.155 773.547C603.544 781.043 597.234 793.225 597.234 806.217V917.121C597.234 929.924 591.105 941.954 580.748 949.48L426.569 1061.52C416.212 1069.05 410.083 1081.08 410.083 1093.88V1565.12C410.083 1580.36 401.433 1594.26 387.772 1601L255.94 1666C242.279 1672.74 233.629 1686.64 233.629 1701.88V1789V1801.68C233.629 1817.65 224.128 1832.09 209.461 1838.42L-10 1933" stroke="#FB8A2E" stroke-width="15" stroke-linecap="round"/>
                    </svg>
                </div>
            </div>
            <div className='product-services'>
                <Container className='container position-relative'>
                    <h4>Products and Services From Salesforce Ecosystem</h4>
                    <Grid container spacing={3}>
                        <img src={LinePattern} alt='' className='line-pattern' />
                        <Grid size={{ xs: 12, md: 3 }}>
                            <div className='service-card'>
                                <img src={Graph} alt='' />
                                <h5>Sales Cloud</h5> 
                                <p>Empower your sales force to drive revenue growth and close deals seamlessly. Harness the power of sales insights for a strategic advantage.</p>
                                <a href='' className='know-more'>
                                    Know more <img src={RightArrow} alt='' /> 
                                </a>
                            </div>
                        </Grid>
                        <Grid size={{ xs: 12, md: 3 }}>
                            <div className='service-card'>
                                <img src={Heart} alt='' />
                                <h5>Service Cloud</h5> 
                                <p>Deliver exceptional customer service and cultivate lasting relationships at scale. Turn customers into brand advocates with outstanding support experiences.</p>
                                <a href='' className='know-more'>
                                    Know more <img src={RightArrow} alt='' /> 
                                </a>
                            </div>
                        </Grid>
                        <Grid size={{ xs: 12, md: 3 }}>
                            <div className='service-card'>
                                <img src={Search} alt='' />
                                <h5>Marketing Cloud</h5> 
                                <p>Drive personalized, data-driven marketing strategies to engage customers and boost ROI. Unlock the potential of marketing automation for extraordinary campaigns.</p>
                                <a href='' className='know-more'>
                                    Know more <img src={RightArrow} alt='' /> 
                                </a>
                            </div>
                        </Grid>
                        <Grid size={{ xs: 12, md: 3 }}>
                            <div className='service-card'>
                                <img src={Cart} alt='' />
                                <h5>Commerce Cloud</h5> 
                                <p>Create seamless, immersive e-commerce experiences to captivate customers and drive growth. Elevate online shopping into an art form that converts visitors into loyal customers.</p>
                                <a href='' className='know-more'>
                                    Know more <img src={RightArrow} alt='' /> 
                                </a>
                            </div>
                        </Grid>
                        <Grid size={{ xs: 12, md: 3 }}>
                            <div className='service-card'>
                                <img src={Location} alt='' />
                                <h5>Field Service Lightning</h5> 
                                <p>Optimize field operations and elevate customer experiences through efficient service delivery. Field service excellence that leaves a lasting impression on your customers.</p>
                                <a href='' className='know-more'>
                                    Know more <img src={RightArrow} alt='' /> 
                                </a>
                            </div>
                        </Grid>
                        <Grid size={{ xs: 12, md: 3 }}>
                            <div className='service-card'>
                                <img src={Heroku} alt='' />
                                <h5>Heroku</h5> 
                                <p>Leverage a powerful platform for building, deploying, and scaling innovative applications swiftly. Heroku is where your app ideas take flight and innovation knows no bounds.</p>
                                <a href='' className='know-more'>
                                    Know more <img src={RightArrow} alt='' /> 
                                </a>
                            </div>
                        </Grid>
                        <Grid size={{ xs: 12, md: 3 }}>
                            <div className='service-card'>
                                <img src={CPQ} alt='' />
                                <h5>CPQ</h5> 
                                <p>Streamline your quoting process and enhance sales efficiency for higher profitability. Quote faster, sell smarter, and boost your bottom line effortlessly.</p>
                                <a href='' className='know-more'>
                                    Know more <img src={RightArrow} alt='' /> 
                                </a>
                            </div>
                        </Grid>
                        <Grid size={{ xs: 12, md: 3 }}>
                            <a href='' className='view-all'>
                                <span>
                                    View all <img src={ArrowNarrowRight} alt='' className='mt-3' /> 
                                </span>                                 
                            </a>
                        </Grid>
                    </Grid>
                </Container>
            </div>
            <div className="solution-for-business">
                <Container className='container'>
                    <h4>How We Provide the Right Solution for Your Business?</h4>
                    <Tabs
                        value={currentTab}
                        scrollButtons={false}
                        onChange={handleTabChange}
                    >
                        {SOLUTION_TABS.map((item, index) => (
                            
                            <Tab label={<h6><span>{item.id}</span> {item.text}</h6>} key={index}  />                            
                        ))}
                    </Tabs>
                    <AtomTabPanel value={currentTab} index={0} className="tab-panel">
                        <Grid container spacing={3} alignItems="center">
                            <Grid size={{ xs: 12, md: 4 }}>
                                <h3>Deep Discovery</h3>
                                <ul>
                                    <li>
                                        <img src={ArrowBendUpRight} alt='' />  
                                        Existing Actors
                                    </li>
                                    <li>
                                        <img src={ArrowBendUpRight} alt='' />  
                                        Existing Infrastructure
                                    </li>
                                    <li>
                                        <img src={ArrowBendUpRight} alt='' />  
                                        Tools They Use or Don't
                                    </li>
                                    <li>
                                        <img src={ArrowBendUpRight} alt='' />  
                                        Actors Assessment for Change
                                    </li>
                                    <li>
                                        <img src={ArrowBendUpRight} alt='' />  
                                        Current Challenges
                                    </li>
                                    <li>
                                        <img src={ArrowBendUpRight} alt='' />  
                                        Future Goals
                                    </li>
                                </ul>
                            </Grid>
                            <Grid size={{ xs: 12, md: 8 }} display={'flex'} justifyContent={'end'} className="position-relative">
                                <img src={Banner} alt='' className='banner' />
                                <img src={Pattern} alt='' />
                            </Grid>
                        </Grid>
                    </AtomTabPanel>
                    <AtomTabPanel value={currentTab} index={1} className="tab-panel">
                        <Grid container spacing={3} alignItems="center">
                            <Grid size={{ xs: 12, md: 4 }}>
                                <h3>Consulting</h3>
                                <ul>
                                    <li>
                                        <img src={ArrowBendUpRight} alt='' />  
                                        Strategic Guidance
                                    </li>
                                    <li>
                                        <img src={ArrowBendUpRight} alt='' />  
                                        Data-Driven Insights
                                    </li>
                                    <li>
                                        <img src={ArrowBendUpRight} alt='' />  
                                        Process Optimization
                                    </li>
                                    <li>
                                        <img src={ArrowBendUpRight} alt='' />  
                                        Innovation Partner
                                    </li>
                                    <li>
                                        <img src={ArrowBendUpRight} alt='' />  
                                        Sustainable Results
                                    </li>
                                </ul>
                            </Grid>
                            <Grid size={{ xs: 12, md: 8 }} display={'flex'} justifyContent={'end'} className="position-relative">
                                <img src={Banner2} alt='' className='banner' />
                                <img src={Pattern} alt='' />
                            </Grid>
                        </Grid>
                    </AtomTabPanel>
                    <AtomTabPanel value={currentTab} index={2} className="tab-panel">
                        <Grid container spacing={3} alignItems="center">
                            <Grid size={{ xs: 12, md: 4 }}>
                                <h3>System Design</h3>
                                <ul>
                                    <li>
                                        <img src={ArrowBendUpRight} alt='' />  
                                        Gap Analysis
                                    </li>
                                    <li>
                                        <img src={ArrowBendUpRight} alt='' />  
                                        Existing vs New System Architecture
                                    </li>
                                    <li>
                                        <img src={ArrowBendUpRight} alt='' />  
                                        Tools They Use or Don't
                                    </li>
                                    <li>
                                        <img src={ArrowBendUpRight} alt='' />  
                                        Actors Assessment for Change
                                    </li>
                                </ul>
                            </Grid>
                            <Grid size={{ xs: 12, md: 8 }} display={'flex'} justifyContent={'end'} className="position-relative">
                                <img src={Banner3} alt='' className='banner' />
                                <img src={Pattern} alt='' />
                            </Grid>
                        </Grid>
                    </AtomTabPanel>
                    <AtomTabPanel value={currentTab} index={3} className="tab-panel">
                        <Grid container spacing={3} alignItems="center">
                            <Grid size={{ xs: 12, md: 4 }}>
                                <h3>Implementation</h3>
                                <ul>
                                    <li>
                                        <img src={ArrowBendUpRight} alt='' />  
                                        Development on New Model
                                    </li>
                                    <li>
                                        <img src={ArrowBendUpRight} alt='' />  
                                        Actor Interview and Recommendation
                                    </li>
                                    <li>
                                        <img src={ArrowBendUpRight} alt='' />  
                                        Integration of New Tools
                                    </li>
                                    <li>
                                        <img src={ArrowBendUpRight} alt='' />  
                                        User Training & Feedbacks
                                    </li>
                                    <li>
                                        <img src={ArrowBendUpRight} alt='' />  
                                        User Adoptions
                                    </li>
                                    <li>
                                        <img src={ArrowBendUpRight} alt='' />  
                                        User Comprehensive/Responsive Support during & After Implementation Cycle.
                                    </li>
                                </ul>
                            </Grid>
                            <Grid size={{ xs: 12, md: 8 }} display={'flex'} justifyContent={'end'} className="position-relative">
                                <img src={Banner4} alt='' className='banner' />
                                <img src={Pattern} alt='' />
                            </Grid>
                        </Grid>
                    </AtomTabPanel>
                    <AtomTabPanel value={currentTab} index={4} className="tab-panel">
                        <Grid container spacing={3} alignItems="center">
                            <Grid size={{ xs: 12, md: 4 }}>
                                <h3>Monitoring & Roadmap</h3>
                                <ul>
                                    <li>
                                        <img src={ArrowBendUpRight} alt='' />  
                                        Observation on New Model
                                    </li>
                                    <li>
                                        <img src={ArrowBendUpRight} alt='' />  
                                        Continues Improvisation
                                    </li>
                                    <li>
                                        <img src={ArrowBendUpRight} alt='' />  
                                        Future Roadmap Strategy
                                    </li>
                                </ul>
                            </Grid>
                            <Grid size={{ xs: 12, md: 8 }} display={'flex'} justifyContent={'end'} className="position-relative">
                                <img src={Banner5} alt='' className='banner' />
                                <img src={Pattern} alt='' />
                            </Grid>
                        </Grid>
                    </AtomTabPanel>
                </Container>
            </div>
            <div className='industries'>
                <Container className='container'>
                    <h4>Industries We Have Worked For</h4>
                    <Grid container spacing={3}>
                        <Grid size={{ xs: 12, md: 3 }}>
                            <div className='service-card'>
                                <img src={Banking} alt='' />
                                <h5>Banking & Finance</h5> 
                                <p>Navigate change seamlessly, innovate tirelessly. Embrace secure, agile tech solutions for a dynamic financial landscape.</p>
                                <a href='' className='know-more'>
                                    Know more <img src={RightArrow} alt='' /> 
                                </a>
                            </div>
                        </Grid>
                        <Grid size={{ xs: 12, md: 3 }}>
                            <div className='service-card'>
                                <img src={Healthcare} alt='' />
                                <h5>Healthcare & Pharma</h5> 
                                <p>Prioritize patients, drive progress. Optimize care, innovate operations, and lead advancements in healthcare and pharma.</p>
                                <a href='' className='know-more'>
                                    Know more <img src={RightArrow} alt='' /> 
                                </a>
                            </div>
                        </Grid>
                        <Grid size={{ xs: 12, md: 3 }}>
                            <div className='service-card'>
                                <img src={Education} alt='' />
                                <h5>Education</h5> 
                                <p>Empower educators, engage learners. Harness tech to inspire students and revolutionize educational experiences.</p>
                                <a href='' className='know-more'>
                                    Know more <img src={RightArrow} alt='' /> 
                                </a>
                            </div>
                        </Grid>
                        <Grid size={{ xs: 12, md: 3 }}>
                            <div className='service-card'>
                                <img src={Manufacturing} alt='' />
                                <h5>Manufacturing</h5> 
                                <p>Revamp operations, boost productivity. Streamline supply chains and fuel manufacturing excellence with tech-driven optimization.</p>
                                <a href='' className='know-more'>
                                    Know more <img src={RightArrow} alt='' /> 
                                </a>
                            </div>
                        </Grid>
                        <Grid size={{ xs: 12, md: 3 }}>
                            <div className='service-card'>
                                <img src={Fintech} alt='' />
                                <h5>Fintech</h5> 
                                <p>Lead with innovation, ensure security. Delight users with cutting-edge tech, providing seamless and trusted fintech services.</p>
                                <a href='' className='know-more'>
                                    Know more <img src={RightArrow} alt='' /> 
                                </a>
                            </div>
                        </Grid>
                        <Grid size={{ xs: 12, md: 3 }}>
                            <div className='service-card'>
                                <img src={Recruitment} alt='' />
                                <h5>Recruitment & Staffing</h5> 
                                <p>Transform hiring experiences, exceed expectations. Embrace tech-driven solutions to streamline talent acquisition and elevate client satisfaction.</p>
                                <a href='' className='know-more'>
                                    Know more <img src={RightArrow} alt='' /> 
                                </a>
                            </div>
                        </Grid>
                        <Grid size={{ xs: 12, md: 3 }}>
                            <div className='service-card'>
                                <img src={Tourism} alt='' />
                                <h5>Tourism & Hospitality</h5> 
                                <p>Craft unforgettable guest journeys. Enhance operations, deliver exceptional experiences, and foster growth in tourism and hospitality.</p>
                                <a href='' className='know-more'>
                                    Know more <img src={RightArrow} alt='' /> 
                                </a>
                            </div>
                        </Grid>
                        <Grid size={{ xs: 12, md: 3 }}>
                            <a href='' className='view-all'>
                                <span>
                                    View all <img src={ArrowNarrowRight} alt='' className='mt-3' /> 
                                </span>  
                            </a>
                        </Grid>
                    </Grid>
                </Container>
            </div>
            <div className='providing-solution'>
                <Container className='container'>
                    <h4>Providing Solutions Across a Range of Industries</h4>
                    <AtomTabs
                        value={currentTab}
                        scrollButtons={true}
                        variant="scrollable"
                        onChange={handleTabChange}
                    >
                        {PROVIDE_SOLUTION_TABS}
                    </AtomTabs>
                    <AtomTabPanel value={currentTab} index={0} className="tab-panel">
                        <div className='logo-section'>
                            <img src={Symega} alt='' />
                            <img src={Swagelok} alt='' />
                            <img src={Cme} alt='' />
                            <img src={Soliflex} alt='' />
                        </div>
                        <div className='logo-section'>
                            <img src={Trevi} alt='' />
                            <img src={ALS} alt='' />
                            <img src={F2} alt='' />
                            <img src={Ecolibrium} alt='' />
                        </div>
                    </AtomTabPanel>
                    <AtomTabPanel value={currentTab} index={1} className="tab-panel">
                        <div className='logo-section'>
                            <img src={Flobiz} alt='' />
                            <img src={FinanceBuddha} alt='' />
                        </div>
                        <div className='logo-section'>
                            <img src={Azzite} alt='' />
                            <img src={Finexus} alt='' />
                        </div>
                    </AtomTabPanel>
                    <AtomTabPanel value={currentTab} index={2} className="tab-panel">
                        <div className='logo-section'>
                            <img src={Quizziz} alt='' />
                            <img src={Excelr} alt='' />
                            <img src={Homeskul} alt='' />
                        </div>
                        <div className='logo-section'>
                            <img src={UWA} alt='' />
                            <img src={relevel} alt='' />
                            <img src={FlameUniversity} alt='' />
                        </div>
                    </AtomTabPanel>
                    <AtomTabPanel value={currentTab} index={3} className="tab-panel">
                        <div className='logo-section'>
                            <img src={IGSTC} alt='' />
                            <img src={AmnestyInternational} alt='' />
                            <img src={BottlesForChange} alt='' />
                        </div>
                        <div className='logo-section'>
                            <img src={FoundationExcellence} alt='' />
                            <img src={Cyberpeace} alt='' />
                        </div>
                    </AtomTabPanel>
                    <AtomTabPanel value={currentTab} index={4} className="tab-panel">
                        <div className='logo-section'>
                            <img src={ArjunNatural} alt='' />
                            <img src={oasis} alt='' />
                            <img src={Twin} alt='' />
                        </div>
                        <div className='logo-section'>
                            <img src={Ekincare} alt='' />
                            <img src={AqmenMedtech} alt='' />
                            <img src={kumarOrganic} alt='' />
                        </div>
                    </AtomTabPanel>
                    <AtomTabPanel value={currentTab} index={5} className="tab-panel">
                        <div className='logo-section'>
                            <img src={Leaders} alt='' />
                            <img src={Ondonte} alt='' />
                            <img src={Hirect} alt='' />
                        </div>
                    </AtomTabPanel>
                    <AtomTabPanel value={currentTab} index={6} className="tab-panel">
                        <div className='logo-section'>
                            <img src={NationalFunding} alt='' />
                            <img src={NorthernArc} alt='' />
                            <img src={Ascendus} alt='' />
                        </div>
                        <div className='logo-section'>
                            <img src={Creditworks} alt='' />
                            <img src={Graciepoint} alt='' />
                            <img src={goeasy} alt='' />
                        </div>
                    </AtomTabPanel>
                    <AtomTabPanel value={currentTab} index={7} className="tab-panel">
                        <div className='logo-section'>
                            <img src={Edwardian} alt='' />
                            <img src={Thrillophilia} alt='' />
                        </div>
                    </AtomTabPanel>
                    <AtomTabPanel value={currentTab} index={8} className="tab-panel">
                        <div className='logo-section'>
                            <img src={Croyez} alt='' />
                        </div>
                    </AtomTabPanel>
                    <AtomTabPanel value={currentTab} index={9} className="tab-panel">
                        <div className='logo-section'>
                            <img src={Bisleri} alt='' />
                            <img src={Kult} alt='' />
                            <img src={mCaffeine} alt='' />
                        </div>
                        <div className='logo-section'>
                            <img src={SwarnaMahal} alt='' />
                            <img src={Neemans} alt='' />
                        </div>
                    </AtomTabPanel>
                    <AtomTabPanel value={currentTab} index={10} className="tab-panel">
                        <div className='logo-section'>
                            <img src={Tridasa} alt='' />
                            <img src={Renaatus} alt='' />
                        </div>
                        <div className='logo-section'>
                            <img src={Vaishnavi} alt='' />
                            <img src={WeWork} alt='' />
                        </div>
                    </AtomTabPanel>
                    <AtomTabPanel value={currentTab} index={11} className="tab-panel">
                        <div className='logo-section'>
                            <img src={Beepkart} alt='' />
                        </div>
                    </AtomTabPanel>
                </Container>
            </div>
            <div className='our-journey'>
                <img src={Wave} alt='' className='wave' /> 
                <Container className='container'>
                    <h4>Our Journey so Far</h4>
                    <Grid container justifyContent="space-between">
                        <Grid size="auto">
                            <h5><Number n={100} /> +</h5>
                            <span>Team Members</span> 
                        </Grid>
                        <Grid size="auto">
                            <h5>50+</h5>
                            <span>Salesforce Solutions</span> 
                        </Grid>
                        <Grid size="auto">
                            <h5>10+</h5>
                            <span>Industry Verticals</span> 
                        </Grid>
                        <Grid size="auto">
                            <h5>30+</h5>
                            <span>Certifications</span> 
                        </Grid>
                    </Grid>
                </Container>
            </div>
            <div className='our-client-say'>
                <Container className='container'>
                    <Grid container spacing={3}>
                        <Grid size={{ xs: 12, md: 6 }} display="flex" alignItems="center">
                            <h4>What Our Clients Say About Us?</h4>
                        </Grid>
                        <Grid size={{ xs: 12, md: 6 }} display="flex" justifyContent="center">
                            <Slider {...settings}>
                                <div className='testimonial'>
                                    <img src={Quotes} alt="" className='quotes' />
                                    <div className='tag'>Edtech</div>
                                    <p>ExcelR's collaboration with Utilitarian Labs in implementing Salesforce CRM has been crucial to our success, streamlining operations in both B2C and B2B domains. Their expertise in our challenging B2B vertical enhanced our sales efficiency and global training delivery, reinforcing our commitment to excellence and innovation in professional and organizational development.</p>
                                    <img src={Excelr} alt="" className='brand' />
                                    <div className='divider'></div>
                                    <div className='client-info'>
                                        <div className='pic'>
                                            <img src={Avatar} alt="" />
                                        </div>
                                        <div className='ml-2'>
                                            <h6>Amit Tavva</h6>
                                            <span>Head of Digital Marketing</span>
                                        </div>
                                    </div>
                                </div>
                                <div className='testimonial'>
                                    <div className='tag'>Edtech</div>
                                    <p>ExcelR's collaboration with Utilitarian Labs in implementing Salesforce CRM has been crucial to our success, streamlining operations in both B2C and B2B domains. Their expertise in our challenging B2B vertical enhanced our sales efficiency and global training delivery, reinforcing our commitment to excellence and innovation in professional and organizational development.</p>
                                    <img src={Excelr} alt="" className='brand' />
                                    <div className='divider'></div>
                                    <div className='client-info'>
                                        <div className='pic'>
                                            <img src={Avatar} alt="" />
                                        </div>
                                        <div className='ml-2'>
                                            <h6>Amit Tavva</h6>
                                            <span>Head of Digital Marketing</span>
                                        </div>
                                    </div>
                                </div>
                            </Slider>
                        </Grid>
                    </Grid>
                </Container>
            </div>
            <div className='conversation-section'>
                <Container className='container'>
                    <div className='conversation-form'>
                        <img src={DotPatternBlue} alt="" className='pattern' />
                        <Grid container spacing={3} alignItems="center">
                            <Grid size={{ xs: 12, md: 4 }}>
                                <h4>Let's Have a Conversation</h4>
                                <p>Please leave your message here so we can take the conversation forward.</p>
                            </Grid>
                            <Grid size={{ xs: 12, md: 8 }}>
                                <div className='white-card'>
                                    <Grid container columnSpacing={{ xs: 1, sm: 2, md: 5 }}>
                                        <Grid size={{ xs: 12, md: 6 }}>
                                            <AtomTextField 
                                                label={"First Name *"}
                                                variant="standard"
                                                type="text"
                                                name="firstName"
                                                color="primary"
                                                value={''}
                                                fullWidth={true}
                                                placeholder='Ex: John'
                                            />
                                        </Grid>
                                        <Grid size={{ xs: 12, md: 6 }}>
                                            <AtomTextField 
                                                label="Last Name *"
                                                variant="standard"
                                                type="text"
                                                name="lastName"
                                                color="primary"
                                                value={''}
                                                fullWidth={true}
                                                placeholder='Ex: Doe'
                                            />
                                        </Grid>
                                        <Grid size={{ xs: 12 }}>
                                            <AtomTextField 
                                                label="Phone Number *"
                                                variant="standard"
                                                type="text"
                                                name="phoneNumber"
                                                color="primary"
                                                value={''}
                                                fullWidth={true}
                                                placeholder='Enter 10-digit number'
                                            />
                                        </Grid>
                                        <Grid size={{ xs: 12 }} className="mt-10">
                                            <AtomButton 
                                                name="primaryButton" 
                                                color="info" 
                                                size='medium' 
                                                variant="contained"
                                            >
                                                Submit
                                            </AtomButton>
                                        </Grid>
                                    </Grid>
                                </div>
                            </Grid>
                        </Grid>
                    </div>
                </Container>
            </div>
        </>
    )
}

export default HomeTemplate