export const SOLUTION_TABS = [
    {
        id: 1,
        text: 'Deep Discovery'
    },
    {
        id: 2,
        text: 'Consulting'
    },
    {
        id: 3,
        text: 'System Design'
    },
    {
        id: 4,
        text: 'Implementation'
    },
    {
        id: 5,
        text: 'Monitoring & Roadmap'
    }
]

export const PROVIDE_SOLUTION_TABS = [
    {
        text: 'Manufacturing'
    },
    {
        text: 'Fintech'
    },
    {
        text: 'EdTech'
    },
    {
        text: 'Non Profit'
    },
    {
        text: 'Healthcare  & Pharma'
    },
    {
        text: 'Recruitment & Staffing'
    },
    {
        text: 'Banking & Finance'
    },
    {
        text: 'Tourism & Hospitality'
    },
    {
        text: 'Visa & Immigration'
    },
    {
        text: 'Retail & Consumer Goods'
    },
    {
        text: 'Real Estate'
    },
    {
        text: 'Automotive'
    }
]