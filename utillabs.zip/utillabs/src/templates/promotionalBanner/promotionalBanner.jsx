import AtomButton from '../../atoms/button/button'
import { Container } from '@mui/material'
import { DotPattern, DotPatternBlue } from '../../helpers/constant/imageUrl'
import './promotionalBanner.scss'

const PromotionalBanner = ({
    heading,
    span,
    secndaryButton = false,
    secndaryButtonText,
    primaryButton = false,
    primaryButtonText,
    video = false,
    videoPoster,
    videoSrc
}) => {
    return (
        <div className="promotional-banner">
            <Container className='container'>
                <h1>
                    {heading} <span>{span}</span>
                </h1>  
                <div className='btn-block'>
                    {secndaryButton ? (
                        <AtomButton name="primaryButton" color="secondary" size='large' variant="contained">
                            {secndaryButtonText}
                        </AtomButton> 
                    ) : null}
                    {primaryButton ? (
                        <AtomButton name="primaryButton" color="primary" size='large' variant="contained">
                            {primaryButtonText}
                        </AtomButton> 
                    ) : null} 
                </div> 
                {video ? (
                    <div className='video-player'>
                        <video controls poster={videoPoster}>                
                            <source src={videoSrc} type="video/mp4" />
                        </video>   
                        <img src={DotPattern} alt="" className='dot-pattern' /> 
                        <img src={DotPatternBlue} alt="" className='dot-pattern-blue' />                         
                    </div> 
                ): null}                          
            </Container>
        </div>
    )
}

export default PromotionalBanner