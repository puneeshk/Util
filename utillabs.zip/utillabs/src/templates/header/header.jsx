import AtomButton from '../../atoms/button/button'
import { Container } from '@mui/material'
import { Logo } from '../../helpers/constant/imageUrl'
import './header.scss'

const HeaderTemplate = ({}) => {
    return (
        <div className="header">
            <Container className='container inner-header'>
                <img src={Logo} alt='' />
                <div className='right-section'>
                    <ul>
                        <li>
                            <a href=''>
                                About Us
                            </a>
                        </li>
                        <li>
                            <a href=''>
                                Careers
                            </a>
                        </li>
                        <li>
                            <a href=''>
                                Products
                            </a>
                        </li>
                        <li>
                            <a href=''>
                                Industries
                            </a>
                        </li>
                        <li>
                            <a href=''>
                                Solutions
                            </a>
                        </li>
                        <li>
                            <a href=''>
                                Services
                            </a>
                        </li>
                        <li>
                            <a href=''>
                                Technology
                            </a>
                        </li>
                    </ul>
                    <AtomButton name="primaryButton" color="primary" size='medium' variant="contained" className="ml-3">Schedule a call</AtomButton>
                </div>
            </Container>
        </div>
    )
} 

export default HeaderTemplate