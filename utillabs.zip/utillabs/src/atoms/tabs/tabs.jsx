import { Tab, Tabs } from "@mui/material"


const AtomTabs = ({
    value,
    variant,
    onChange,
    children,
    scrollButtons,
}) => {
    return (
        <>
            <Tabs
                value={value}
                variant={variant}
                onChange={onChange}
                scrollButtons={scrollButtons}
            >
                {children?.map((item, index) =>  {
                    return (
                        <Tab
                            icon={item.icon}
                            key={item.text + index}
                            label={item.label || item.text}
                            disabled={item.disabled}
                        />
                    )
                })}
            </Tabs>
        </>
    )
}

export default AtomTabs