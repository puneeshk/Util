import { Button } from "@mui/material"
import './button.scss'

const AtomButton = ({
    disable = false,
    type = 'button',
    onClick,
    color,
    variant = 'text',
    size = 'small',
    name,
    fullWidth = false,
    startIcon,
    endIcon,
    className,
    children
}) => {
    const handleAtomButtonClick = () => {
        if(!disable && onClick) {
            onClick()
        }
    }
    return (
        <Button
            disabled={disable}
            type={type}
            onClick={handleAtomButtonClick}
            color={color}
            variant={variant}
            size={size}
            name={name}
            fullWidth={fullWidth}
            startIcon={startIcon}
            endIcon={endIcon}
            className={className}
        >
            {children}
        </Button>
    )
}

export default AtomButton